-- ViewPetList.lua
local addonName, addonTable = ...

local viewPetList = CreateFrame("Frame")
viewPetList:Hide()

-- Current filter states (Setting Family to nil defaults to "All Pets")
local selectedFamily = nil
local selectedAbility = nil 
local selectedSpeed = nil

-- 1. Header & Controls
local titleText = viewPetList:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
titleText:SetPoint("TOPLEFT", 20, -15)
titleText:SetText("Pet Lookup")

-- Create the Family Dropdown
local familyDropdown = CreateFrame("Frame", "NanaPetFamilyDropdown", viewPetList, "UIDropDownMenuTemplate")
familyDropdown:SetPoint("TOPLEFT", viewPetList, "TOPLEFT", 0, -45)
UIDropDownMenu_SetWidth(familyDropdown, 110)

-- Create the Ability Dropdown
local abilityDropdown = CreateFrame("Frame", "NanaPetAbilityDropdown", viewPetList, "UIDropDownMenuTemplate")
abilityDropdown:SetPoint("TOPLEFT", familyDropdown, "TOPRIGHT", -15, 0)
UIDropDownMenu_SetWidth(abilityDropdown, 120)

-- Create the Speed Dropdown
local speedDropdown = CreateFrame("Frame", "NanaPetSpeedDropdown", viewPetList, "UIDropDownMenuTemplate")
speedDropdown:SetPoint("TOPLEFT", abilityDropdown, "TOPRIGHT", -15, 0)
UIDropDownMenu_SetWidth(speedDropdown, 90)

-- Forward declaration
local UpdateNPCList

-- Dropdown Initializers
UIDropDownMenu_Initialize(familyDropdown, function(self, level, menuList)
    local info = UIDropDownMenu_CreateInfo()
    
    info.text = "All Pets"
    info.value = nil
    info.func = function(self)
        -- Reset secondary filters when returning to All Pets
        UpdateNPCList(nil, nil, nil)
        UIDropDownMenu_SetSelectedValue(familyDropdown, nil)
    end
    info.checked = (selectedFamily == nil)
    UIDropDownMenu_AddButton(info)

    local families = {}
    if HunterTameableDB then
        for k in pairs(HunterTameableDB) do table.insert(families, k) end
        table.sort(families)
    end
    
    for _, fam in ipairs(families) do
        info.text = fam
        info.value = fam
        info.func = function(self)
            UpdateNPCList(self.value, nil, nil)
            UIDropDownMenu_SetSelectedValue(familyDropdown, self.value)
        end
        info.checked = (selectedFamily == fam)
        UIDropDownMenu_AddButton(info)
    end
end)

UIDropDownMenu_Initialize(abilityDropdown, function(self, level, menuList)
    local info = UIDropDownMenu_CreateInfo()
    info.text = "All Abilities"
    info.value = nil
    info.func = function(self) UpdateNPCList(selectedFamily, nil, selectedSpeed) end
    info.checked = (selectedAbility == nil)
    UIDropDownMenu_AddButton(info)

    local uniqueMap = {}
    local abilities = {}
    
    if HunterTameableDB then
        for fam, beasts in pairs(HunterTameableDB) do
            -- Only gather abilities if we are looking at this family, or if "All Pets" is active
            if selectedFamily == nil or selectedFamily == fam then
                for _, beast in ipairs(beasts) do
                    if beast.abilities then
                        for _, ab in ipairs(beast.abilities) do
                            local baseAb = string.gsub(ab, "%d+", "")
                            baseAb = strtrim(baseAb)
                            if baseAb ~= "" and not uniqueMap[baseAb] then
                                uniqueMap[baseAb] = true
                                table.insert(abilities, baseAb)
                            end
                        end
                    end
                end
            end
        end
        table.sort(abilities)
    end

    for _, ab in ipairs(abilities) do
        info.text = ab
        info.value = ab
        info.func = function(self) UpdateNPCList(selectedFamily, self.value, selectedSpeed) end
        info.checked = (selectedAbility == ab)
        UIDropDownMenu_AddButton(info)
    end
end)

UIDropDownMenu_Initialize(speedDropdown, function(self, level, menuList)
    local info = UIDropDownMenu_CreateInfo()
    info.text = "All Speeds"
    info.value = nil
    info.func = function(self) UpdateNPCList(selectedFamily, selectedAbility, nil) end
    info.checked = (selectedSpeed == nil)
    UIDropDownMenu_AddButton(info)

    local uniqueMap = {}
    local speeds = {}
    
    if HunterTameableDB then
        for fam, beasts in pairs(HunterTameableDB) do
            if selectedFamily == nil or selectedFamily == fam then
                for _, beast in ipairs(beasts) do
                    if beast.speed and beast.speed ~= "" and not uniqueMap[beast.speed] then
                        uniqueMap[beast.speed] = true
                        table.insert(speeds, beast.speed)
                    end
                end
            end
        end
        table.sort(speeds)
    end

    for _, spd in ipairs(speeds) do
        info.text = spd .. " Speed"
        info.value = spd
        info.func = function(self) UpdateNPCList(selectedFamily, selectedAbility, self.value) end
        info.checked = (selectedSpeed == spd)
        UIDropDownMenu_AddButton(info)
    end
end)

-- 2. Scroll Area Setup
local scrollFrame = CreateFrame("ScrollFrame", nil, viewPetList, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", 15, -85)
scrollFrame:SetPoint("BOTTOMRIGHT", -35, 50)

local content = CreateFrame("Frame")
content:SetSize(470, 500)
scrollFrame:SetScrollChild(content)

local npcRows = {}
local rowHeight = 32

-- Increased pool limit to 500 to comfortably fit all beasts in the game
for i = 1, 500 do
    local row = CreateFrame("Frame", nil, content)
    row:SetSize(470, rowHeight)
    row:SetPoint("TOPLEFT", content, "TOPLEFT", 10, -((i - 1) * rowHeight))
    
    local divider = row:CreateTexture(nil, "BACKGROUND")
    divider:SetColorTexture(1, 1, 1, 0.15)
    PixelUtil.SetPoint(divider, "BOTTOMLEFT", row, "BOTTOMLEFT", 0, 0)
    PixelUtil.SetPoint(divider, "BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 0)
    PixelUtil.SetHeight(divider, 1)
    
    row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.name:SetPoint("LEFT", 0, 6)
    
    row.info = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.info:SetPoint("LEFT", 0, -8)
    
    row.skills = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.skills:SetPoint("RIGHT", -10, 0)
    
    row:Hide()
    npcRows[i] = row
end

-- 3. Populate Function
UpdateNPCList = function(family, requiredAbility, requiredSpeed)
    selectedFamily = family 
    selectedAbility = requiredAbility
    selectedSpeed = requiredSpeed
    
    UIDropDownMenu_SetText(familyDropdown, selectedFamily or "All Pets")
    UIDropDownMenu_SetText(abilityDropdown, selectedAbility or "All Abilities")
    UIDropDownMenu_SetText(speedDropdown, selectedSpeed and (selectedSpeed .. " Speed") or "All Speeds")
    
    for _, row in ipairs(npcRows) do row:Hide() end
    
    local familyBeasts = {}
    if HunterTameableDB then
        for fam, beasts in pairs(HunterTameableDB) do
            if selectedFamily == nil or selectedFamily == fam then
                for _, b in ipairs(beasts) do
                    b.familyName = fam -- Inject family name for display context
                    table.insert(familyBeasts, b)
                end
            end
        end
    end

    table.sort(familyBeasts, function(a, b)
        local lvlA = tonumber(string.match(a.level, "^%d+")) or 0
        local lvlB = tonumber(string.match(b.level, "^%d+")) or 0
        if lvlA == lvlB then return a.name < b.name end
        return lvlA < lvlB
    end)
    
    local rowIndex = 1
    
    for _, beast in ipairs(familyBeasts) do
        local hasAbility = true
        local hasSpeed = true
        
        if requiredAbility then
            hasAbility = false
            if beast.abilities then
                for _, ab in ipairs(beast.abilities) do
                    if string.find(ab, requiredAbility) then
                        hasAbility = true
                        break
                    end
                end
            end
        end
        
        if requiredSpeed and beast.speed ~= requiredSpeed then
            hasSpeed = false
        end
        
        if hasAbility and hasSpeed and npcRows[rowIndex] then
            local row = npcRows[rowIndex]
            
            local nameText = beast.name
            if beast.rare then nameText = "|cFF00FFFF[Rare]|r " .. nameText end
            if beast.isNew then nameText = nameText .. " |cFF00FF00[New]|r" end
            row.name:SetText(nameText)
            
            -- If looking at the global "All Pets" list, explicitly state what Family the beast belongs to
            local familyPrefix = (selectedFamily == nil) and (beast.familyName .. " - ") or ""
            local speedText = beast.speed and (" - " .. beast.speed .. " Speed") or ""
            
            row.info:SetText("|cFFCCCCCC" .. familyPrefix .. beast.zone .. " (Lvl " .. beast.level .. ")" .. speedText .. "|r")
            
            if beast.abilities and #beast.abilities > 0 then
                row.skills:SetText(table.concat(beast.abilities, ", "))
            else
                row.skills:SetText("")
            end
            
            row:Show()
            rowIndex = rowIndex + 1
        end
    end
end

-- Initial render
UpdateNPCList(selectedFamily, selectedAbility, selectedSpeed)

addonTable.ViewPetList = viewPetList
addonTable.UpdateNPCList = UpdateNPCList